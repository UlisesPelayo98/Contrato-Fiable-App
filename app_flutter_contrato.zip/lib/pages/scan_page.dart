
import 'package:flutter/material.dart';

class ScanPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Escanear Contrato')),
      body: Center(child: Text('Función de escaneo próximamente.')),
    );
  }
}

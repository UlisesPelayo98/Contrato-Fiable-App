
import 'package:flutter/material.dart';

class TranslatePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Traducir Contrato')),
      body: Center(child: Text('Función de traducción próximamente.')),
    );
  }
}

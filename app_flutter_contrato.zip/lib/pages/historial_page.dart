
import 'package:flutter/material.dart';

class HistorialPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Historial de Contratos')),
      body: Center(child: Text('Aquí se mostrarán los contratos guardados.')),
    );
  }
}

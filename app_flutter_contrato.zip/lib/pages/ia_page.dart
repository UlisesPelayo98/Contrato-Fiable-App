
import 'package:flutter/material.dart';

class IaPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Análisis con IA')),
      body: Center(child: Text('Función de IA próximamente.')),
    );
  }
}

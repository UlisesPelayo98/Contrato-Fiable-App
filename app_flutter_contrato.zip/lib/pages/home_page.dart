
// Actualización para guardar contratos al evaluarlos
// Se debe agregar: import '../services/storage_service.dart';
// Y usar el método: storage.guardarContrato(_controller.text, resultadoIA: resultado);

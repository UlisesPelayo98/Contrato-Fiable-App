
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _controller = TextEditingController();
  String resultado = '';

  void evaluarContrato(String texto) {
    final palabrasRiesgosas = [
      'renuncia',
      'obligatorio',
      'sin derecho',
      'irrevocable',
      'penalización',
      'no reembolsable',
      'exclusividad',
      'confidencial',
      'permanencia',
      'demanda',
      'arbitraje',
      'indemnización',
      'rescindir'
    ];

    final textoMin = texto.toLowerCase();
    final riesgos = palabrasRiesgosas.where((p) => textoMin.contains(p)).toList();

    setState(() {
      resultado = riesgos.isEmpty
          ? 'El contrato parece seguro.'
          : 'Riesgos detectados: ${riesgos.join(", ")}';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Evaluador de Contratos')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              maxLines: 8,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Texto del contrato',
              ),
            ),
            SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => evaluarContrato(_controller.text),
              child: Text('Evaluar Contrato'),
            ),
            SizedBox(height: 20),
            Text(resultado),
            Divider(),
            Wrap(
              spacing: 10,
              children: [
                ElevatedButton(
                  onPressed: () => Navigator.pushNamed(context, '/scan'),
                  child: Text('Escanear'),
                ),
                ElevatedButton(
                  onPressed: () => Navigator.pushNamed(context, '/historial'),
                  child: Text('Historial'),
                ),
                ElevatedButton(
                  onPressed: () => Navigator.pushNamed(context, '/ia'),
                  child: Text('IA'),
                ),
                ElevatedButton(
                  onPressed: () => Navigator.pushNamed(context, '/translate'),
                  child: Text('Traducir'),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
